<?php
if(is_admin()){
	require SPIKO_TEMPLATE_DIR . '/admin/inc/class-spicethemes-about-page.php';
}

require SPIKO_TEMPLATE_DIR . '/admin/inc/plugin-include-control.php';
require SPIKO_TEMPLATE_DIR . '/admin/inc/include-companion.php';


