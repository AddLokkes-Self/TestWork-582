<form class="input-group" method="get" id="searchform" action="<?php echo esc_url(home_url('/')); ?>">
    <input type="search" class="form-control" placeholder="<?php echo esc_attr_x('Search', 'placeholder', 'spiko' ); ?>" value="" name="s" id="s"/>
    <button class="search-submit fa fa-search" type="submit"></button>
</form>